package controller;

import javafx.stage.Stage;

public class AdminController {
	private static Stage stage;

	public void start(Stage mainStage) {
		stage = mainStage;
	}
}
