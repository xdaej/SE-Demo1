package model;

/**
 * 
 * @author leonardoroman
 *
 */
public class Items {
	String item;
	float price;
	public Items(String item, float price) {
		this.item = item;
		this.price = price;
	}
}
