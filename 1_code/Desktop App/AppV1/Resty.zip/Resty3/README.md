# RestaurantAutomationMainSystem
Software engineer project. This is the main system for management purposes such as seating guests, editing exinting orders,
managing reservation, floor state, employees accountability and more. 
